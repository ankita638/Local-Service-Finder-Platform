package com.example.sb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocalServiceFinderApplicationTests {

	@Test
	void contextLoads() {
	}

}
