package com.localsvcfinder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LocalServiceFinderApplication {
    public static void main(String[] args) {
        SpringApplication.run(LocalServiceFinderApplication.class, args);
    }
}
